import React from 'react';

const AuthCodePage: React.FC = () => {
    return (
        <div className="w-[1512px] h-[982px] relative bg-white flex-col justify-start items-start inline-flex">
            <div className="w-[126.44px] h-8 relative" />
            <div className="w-[1112px] text-center text-neutral-900 text-3xl font-normal font-['Poppins'] tracking-tight">
                Welcome, Please complete your registration to activate your account.
            </div>
            <div className="w-[452px] h-[392px] pt-10 pb-5 bg-gray-50 rounded-2xl shadow border border-gray-200 flex-col justify-start items-center gap-5 inline-flex">
                <div className="text-neutral-900 text-[23px] font-semibold font-['Poppins'] leading-loose">
                    Activate your HIFI account
                </div>
                <div className="self-stretch h-52 px-5 py-[30px] bg-white border border-gray-200 flex-col justify-center items-center gap-8 flex">
                    <div className="self-stretch text-center text-neutral-900 text-base font-normal font-['Poppins'] leading-normal">
                        To continue, please enter the 6-digit registration code sent to your email
                    </div>
                    <div className="justify-center items-center gap-4 inline-flex">
                        <div className="w-[286px] h-14 justify-center items-center gap-4 inline-flex">
                            <div className="justify-start items-start flex">
                                <div className="px-2.5 py-1 bg-white rounded-tl-lg rounded-bl-lg border-l border-t border-b border-gray-400 flex-col justify-center items-center gap-2.5 inline-flex">
                                    <div className="opacity-0 text-center text-neutral-900 text-[32px] font-medium font-['Poppins'] tracking-tight">9</div>
                                </div>
                                <div className="px-2.5 py-1 bg-white border-l border-t border-b border-gray-400 flex-col justify-center items-center gap-2.5 inline-flex">
                                    <div className="opacity-0 text-center text-neutral-900 text-[32px] font-medium font-['Poppins'] tracking-tight">9</div>
                                </div>
                                <div className="px-2.5 py-1 bg-white rounded-tr-lg rounded-br-lg border border-gray-400 flex-col justify-center items-center gap-2.5 inline-flex">
                                    <div className="opacity-0 text-center text-neutral-900 text-[32px] font-medium font-['Poppins'] tracking-tight">9</div>
                                </div>
                            </div>
                            <div className="h-1 p-2.5 bg-gray-400 rounded-lg" />
                            <div className="justify-start items-start flex">
                                <div className="px-2.5 py-1 bg-white rounded-tl-lg rounded-bl-lg border-l border-t border-b border-gray-400 flex-col justify-center items-center gap-2.5 inline-flex">
                                    <div className="opacity-0 text-center text-neutral-900 text-[32px] font-medium font-['Poppins'] tracking-tight">9</div>
                                </div>
                                <div className="px-2.5 py-1 bg-white border-l border-t border-b border-gray-400 flex-col justify-center items-center gap-2.5 inline-flex">
                                    <div className="opacity-0 text-center text-neutral-900 text-[32px] font-medium font-['Poppins'] tracking-tight">9</div>
                                </div>
                                <div className="px-2.5 py-1 bg-white rounded-tr-lg rounded-br-lg border border-gray-400 flex-col justify-center items-center gap-2.5 inline-flex">
                                    <div className="opacity-0 text-center text-neutral-900 text-[32px] font-medium font-['Poppins'] tracking-tight">9</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="self-stretch px-5 py-2.5 justify-between items-start inline-flex">
                    <div className="w-[334px] px-3.5 py-1 bg-violet-800 bg-opacity-40 rounded-md flex-col justify-start items-center gap-2 inline-flex">
                        <div className="justify-start items-start gap-2 inline-flex">
                            <div className="text-white text-base font-normal font-['Poppins'] leading-normal">Confirm</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AuthCodePage;
